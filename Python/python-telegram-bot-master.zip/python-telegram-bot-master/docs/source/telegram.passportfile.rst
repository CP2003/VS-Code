:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/passport/passportfile.py

telegram.PassportFile
=====================

.. autoclass:: telegram.PassportFile
    :members:
    :show-inheritance:
