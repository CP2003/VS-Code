:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/payment/successfulpayment.py

telegram.SuccessfulPayment
==========================

.. autoclass:: telegram.SuccessfulPayment
    :members:
    :show-inheritance:
