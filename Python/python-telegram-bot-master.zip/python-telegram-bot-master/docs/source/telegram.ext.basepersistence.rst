:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/basepersistence.py

telegram.ext.BasePersistence
============================

.. autoclass:: telegram.ext.BasePersistence
    :members:
    :show-inheritance:
