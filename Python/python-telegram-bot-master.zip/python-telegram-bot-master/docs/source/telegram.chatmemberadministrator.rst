:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/chatmember.py

telegram.ChatMemberAdministrator
================================

.. autoclass:: telegram.ChatMemberAdministrator
    :members:
    :show-inheritance:
