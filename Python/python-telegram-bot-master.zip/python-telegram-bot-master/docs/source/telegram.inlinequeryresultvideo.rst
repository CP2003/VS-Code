:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultvideo.py

telegram.InlineQueryResultVideo
===============================

.. autoclass:: telegram.InlineQueryResultVideo
    :members:
    :show-inheritance:
