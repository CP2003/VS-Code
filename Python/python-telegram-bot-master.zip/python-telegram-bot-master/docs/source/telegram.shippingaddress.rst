:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/payment/shippingaddress.py

telegram.ShippingAddress
========================

.. autoclass:: telegram.ShippingAddress
    :members:
    :show-inheritance:
