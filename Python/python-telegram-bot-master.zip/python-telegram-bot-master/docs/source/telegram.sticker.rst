:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/sticker.py

telegram.Sticker
================

.. autoclass:: telegram.Sticker
    :members:
    :show-inheritance:
