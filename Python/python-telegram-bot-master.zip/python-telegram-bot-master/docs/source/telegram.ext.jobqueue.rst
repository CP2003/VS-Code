:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/jobqueue.py

telegram.ext.JobQueue
=====================

.. autoclass:: telegram.ext.JobQueue
    :members:
    :show-inheritance:
