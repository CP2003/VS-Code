:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/user.py

telegram.User
=============

.. autoclass:: telegram.User
    :members:
    :show-inheritance:
