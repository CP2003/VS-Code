:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/regexhandler.py

telegram.ext.RegexHandler
=========================

.. autoclass:: telegram.ext.RegexHandler
    :members:
    :show-inheritance:
