:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/defaults.py

telegram.ext.Defaults
=====================

.. autoclass:: telegram.ext.Defaults
    :members:
    :show-inheritance:
