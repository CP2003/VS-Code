:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/chatpermissions.py

telegram.ChatPermissions
========================

.. autoclass:: telegram.ChatPermissions
    :members:
    :show-inheritance:
