:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/updater.py

telegram.ext.Updater
====================

.. autoclass:: telegram.ext.Updater
    :members:
    :show-inheritance:
