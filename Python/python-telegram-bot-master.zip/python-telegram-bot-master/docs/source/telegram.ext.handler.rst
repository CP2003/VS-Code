:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/handler.py

telegram.ext.Handler
====================

.. autoclass:: telegram.ext.Handler
    :members:
    :show-inheritance:
