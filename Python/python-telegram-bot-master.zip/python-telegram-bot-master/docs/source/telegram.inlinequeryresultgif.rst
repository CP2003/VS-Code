:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultgif.py

telegram.InlineQueryResultGif
=============================

.. autoclass:: telegram.InlineQueryResultGif
    :members:
    :show-inheritance:
