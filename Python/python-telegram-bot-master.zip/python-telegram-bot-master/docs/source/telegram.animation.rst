:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/animation.py

telegram.Animation
==================

.. autoclass:: telegram.Animation
    :members:
    :show-inheritance:
