:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresult.py

telegram.InlineQueryResult
==========================

.. autoclass:: telegram.InlineQueryResult
    :members:
    :show-inheritance:
