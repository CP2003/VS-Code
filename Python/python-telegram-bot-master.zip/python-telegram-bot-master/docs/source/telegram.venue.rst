:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/venue.py

telegram.Venue
==============

.. autoclass:: telegram.Venue
    :members:
    :show-inheritance:
