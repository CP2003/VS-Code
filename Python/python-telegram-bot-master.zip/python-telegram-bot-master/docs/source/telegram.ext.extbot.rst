:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/extbot.py

telegram.ext.ExtBot
===================

.. autoclass:: telegram.ext.ExtBot
    :show-inheritance:

    .. autofunction:: telegram.ext.ExtBot.insert_callback_data
