:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/callbackdatacache.py

telegram.ext.InvalidCallbackData
================================

.. autoclass:: telegram.ext.InvalidCallbackData
    :members:
    :show-inheritance:
