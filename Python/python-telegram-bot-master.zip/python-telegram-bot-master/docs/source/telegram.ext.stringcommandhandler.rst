:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/stringcommandhandler.py

telegram.ext.StringCommandHandler
=================================

.. autoclass:: telegram.ext.StringCommandHandler
    :members:
    :show-inheritance:
