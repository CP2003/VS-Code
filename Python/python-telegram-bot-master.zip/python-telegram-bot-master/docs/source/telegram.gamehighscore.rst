:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/games/gamehighscore.py

telegram.GameHighScore
======================

.. autoclass:: telegram.GameHighScore
    :members:
    :show-inheritance:
