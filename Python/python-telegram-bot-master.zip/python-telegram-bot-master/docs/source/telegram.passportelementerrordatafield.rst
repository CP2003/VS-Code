:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/passport/passportelementerrors.py

telegram.PassportElementErrorDataField
======================================

.. autoclass:: telegram.PassportElementErrorDataField
    :members:
    :show-inheritance:
