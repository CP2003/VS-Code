:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/botcommandscope.py

telegram.BotCommandScopeDefault
===============================

.. autoclass:: telegram.BotCommandScopeDefault
    :members:
    :show-inheritance: