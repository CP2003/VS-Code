:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/videonote.py

telegram.VideoNote
==================

.. autoclass:: telegram.VideoNote
    :members:
    :show-inheritance:
