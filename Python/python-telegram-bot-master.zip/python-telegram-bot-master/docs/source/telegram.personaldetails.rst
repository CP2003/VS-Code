:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/passport/data.py

telegram.PersonalDetails
========================

.. autoclass:: telegram.PersonalDetails
    :members:
    :show-inheritance:
