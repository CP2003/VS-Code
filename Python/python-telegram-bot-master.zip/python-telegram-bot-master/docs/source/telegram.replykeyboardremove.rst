:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/replykeyboardremove.py

telegram.ReplyKeyboardRemove
============================

.. autoclass:: telegram.ReplyKeyboardRemove
    :members:
    :show-inheritance:
