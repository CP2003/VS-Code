:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/passport/passportelementerrors.py

telegram.PassportElementError
=============================

.. autoclass:: telegram.PassportElementError
    :members:
    :show-inheritance:
