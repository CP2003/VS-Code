:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/contexttypes.py

telegram.ext.ContextTypes
=========================

.. autoclass:: telegram.ext.ContextTypes
    :members:
    :show-inheritance:
