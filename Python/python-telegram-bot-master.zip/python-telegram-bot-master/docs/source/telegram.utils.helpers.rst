:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/utils/helpers.py

telegram.utils.helpers Module
=============================

.. automodule:: telegram.utils.helpers
    :members:
    :show-inheritance:
