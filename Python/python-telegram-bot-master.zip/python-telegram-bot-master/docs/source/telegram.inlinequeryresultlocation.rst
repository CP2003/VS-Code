:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultlocation.py

telegram.InlineQueryResultLocation
==================================

.. autoclass:: telegram.InlineQueryResultLocation
    :members:
    :show-inheritance:
