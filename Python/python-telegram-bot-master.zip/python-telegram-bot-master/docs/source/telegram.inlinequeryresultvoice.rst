:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultvoice.py

telegram.InlineQueryResultVoice
===============================

.. autoclass:: telegram.InlineQueryResultVoice
    :members:
    :show-inheritance:
